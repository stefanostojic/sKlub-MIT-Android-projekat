package com.stefan.sklub;

import android.location.Location;

public class User {
    public String name;
    public String surname;
    public String address;
    public Location location;
    public User[] users;

    public User(String name, String surname, String address, Location location, User[] users) {
        this.name = name;
        this.surname = surname;
        this.address = address;
        this.location = location;
        this.users = users;
    }
}
