package com.stefan.sklub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.location.Location;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final String TAG = "onCreate()";
        final FirebaseFirestore db = FirebaseFirestore.getInstance();

        TextView mTextView = (TextView) findViewById(R.id.textView);
        Button mButton = (Button) findViewById(R.id.button);
        Button mBtnLogin = (Button) findViewById(R.id.btnLogin);
        final EditText mEtUserName = (EditText) findViewById(R.id.et_user_name);
        EditText mEtUserSurname = (EditText) findViewById(R.id.et_user_surname);

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Log.i(TAG, "klik na dugme");

            Map<String, Object> user = new HashMap<>();
            user.put("first", "Ada");
            user.put("last", "Lovelace");
            user.put("born", 1815);

            db.collection("users")
            .add(user)
            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                @Override
                public void onSuccess(DocumentReference documentReference) {
                Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                }
            })
            .addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                Log.w(TAG, "Error adding document", e);
                }
            });
            }
        });

        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Log.i(TAG, "klik na login");

            db.collection("users")
            .whereEqualTo("name", mEtUserName.getText())
            .get()
            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.i(TAG, document.getId() + " => " + document.getData());
                    }

                } else {
                    Log.w(TAG, "Error getting documents.", task.getException());
                }
                }
            });
            }
        });

    }
}
